# Operação Sombra: Última Vigília

Jogo FPS arcade offline, em HTML5 Canvas, pensado para celular em modo paisagem.

## Jogar
Abra `index.html` em um navegador moderno. No celular, extraia o ZIP e abra o arquivo pelo navegador. Não exige login, Google, servidor ou internet.

## Controles
- Setas na tela: movimentar e virar
- ATIRAR: disparar
- MIRAR: aumentar precisão
- RECARREGAR: recarregar o pente
- Arsenal: alternar entre rifle, pistola, escopeta e sniper

## Conteúdo
- Ondas progressivas e limite de zumbis simultâneos
- Vida, munição do pente e reserva
- Recompensas de baú a cada três ondas
- Capa e menu em português
- Controles touch e teclado

Observação: esta versão é um jogo arcade 2D com perspectiva simulada, totalmente local. Não inclui multiplayer real, login online, servidores públicos ou APK assinado.
